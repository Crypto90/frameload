"""FrameLoad: On-Device VR Sideloading, Catalog Browser, and Installer for Steam Frame."""

__version__ = "1.0.9"
